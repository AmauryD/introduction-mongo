require("dotenv").config()
module.exports = async function() {
  console.log("Setup Mongo Connection")
}
